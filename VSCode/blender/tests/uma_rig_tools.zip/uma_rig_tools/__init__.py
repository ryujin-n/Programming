# ═══════════════════════════════════════════════════════════════════════════════
#  UMA RIG TOOLS — Blender Addon
#  Combines: Eye Rig, Finger Controller, Hand Controller, Ear Roll,
#            Shape Keys Combiner, Skeleton Cleanup
# ═══════════════════════════════════════════════════════════════════════════════

bl_info = {
    "name":        "Uma Rig Tools",
    "author":      "Auto-generated",
    "version":     (2, 0, 0),
    "blender":     (5, 0, 0),
    "location":    "View3D > N-Panel > Uma Rig",
    "description": "Complete UmaMusume rig automation: eyes, fingers, hands, ears, shape keys",
    "category":    "Rigging",
}

import bpy
import math
import mathutils
import re
import pathlib
from collections import defaultdict
from bpy.types  import Panel, Operator, PropertyGroup, UIList
from bpy.props  import (StringProperty, FloatProperty, BoolProperty,
                         PointerProperty, CollectionProperty, IntProperty)


# ─────────────────────────────────────────────────────────────────────────────
#  UTILS
# ─────────────────────────────────────────────────────────────────────────────

def _addon_dir() -> pathlib.Path:
    return pathlib.Path(__file__).parent


def _actions_path() -> pathlib.Path:
    return _addon_dir() / "actions.py"


def safe_set(obj, attr, value):
    if hasattr(obj, attr):
        try:
            setattr(obj, attr, value)
        except Exception as e:
            print(f"  [warn] {attr} = {value!r} → {e}")


def ensure_slot_name(action, display_name="rig"):
    if not hasattr(action, 'slots'):
        return
    for slot in action.slots:
        safe_set(slot, 'name_display', display_name)


def _poll_armature(self, obj):
    return obj.type == 'ARMATURE'

def _poll_mesh(self, obj):
    return obj.type == 'MESH'


# ─────────────────────────────────────────────────────────────────────────────
#  ACTIONS LOADER
# ─────────────────────────────────────────────────────────────────────────────

def load_actions_data():
    filepath = _actions_path()
    if not filepath.exists():
        raise FileNotFoundError(f"actions.py not found in addon directory:\n  {filepath}")
    namespace = {}
    exec(filepath.read_text(encoding="utf-8"), namespace)
    if "ACTIONS_DATA" not in namespace:
        raise KeyError("ACTIONS_DATA not found in actions.py")
    return namespace["ACTIONS_DATA"]


def recreate_actions(actions_data, overwrite=False, fake_user=True):
    created, skipped = [], []
    for action_data in actions_data:
        name = action_data.get("name", "<no name>")
        if name in bpy.data.actions:
            if not overwrite:
                skipped.append(name)
                continue
            bpy.data.actions.remove(bpy.data.actions[name])

        action = bpy.data.actions.new(name)
        for fc_data in action_data.get("fcurves", []):
            try:
                fc = action.fcurves.new(
                    data_path    = fc_data["data_path"],
                    index        = fc_data["array_index"],
                    action_group = fc_data.get("group") or "",
                )
            except Exception as e:
                print(f"  [actions] F-Curve error '{fc_data['data_path']}': {e}")
                continue
            fc.extrapolation = fc_data.get("extrapolation", "CONSTANT")
            keyframes = fc_data.get("keyframes", [])
            if not keyframes:
                continue
            fc.keyframe_points.add(len(keyframes))
            fc.keyframe_points.foreach_set("co",           [v for kp in keyframes for v in kp["co"]])
            fc.keyframe_points.foreach_set("handle_left",  [v for kp in keyframes for v in kp["handle_left"]])
            fc.keyframe_points.foreach_set("handle_right", [v for kp in keyframes for v in kp["handle_right"]])
            for i, kp_data in enumerate(keyframes):
                kp = fc.keyframe_points[i]
                kp.handle_left_type  = kp_data.get("handle_left_type",  "AUTO")
                kp.handle_right_type = kp_data.get("handle_right_type", "AUTO")
                kp.interpolation     = kp_data.get("interpolation", "BEZIER")
                kp.easing            = kp_data.get("easing", "AUTO")
            fc.update()
        ensure_slot_name(action, "rig")
        action.use_fake_user = fake_user
        created.append(name)
    print(f"[actions] Created: {len(created)}  Skipped: {len(skipped)}")
    return created


# ─────────────────────────────────────────────────────────────────────────────
#  FINGER CONTROLLER LOGIC
# ─────────────────────────────────────────────────────────────────────────────

FINGER_PREFIXES    = ["c_thumb", "c_index", "c_middle", "c_ring", "c_pinky"]
FINGER_SIDES       = [".l", ".r"]
Z_OFFSET           = 0.02
Y_OFFSET           = -0.02
EXCLUDE_SUBSTRINGS = ["_base", "_meta", "_root", "c_thumb0", "c_thumb1"]
ROLL_FINGERS       = math.radians(284)
ROLL_THUMB         = math.radians(309)


def _split_finger_side(name):
    for side in FINGER_SIDES:
        if name.lower().endswith(side):
            return name[:-len(side)], name[-len(side):]
    return name, None

def _get_finger_prefix(base):
    lower = base.lower()
    for p in FINGER_PREFIXES:
        if p in lower:
            return p
    return None

def _is_roll_bone(name):        return "_roll" in name.lower()

def _is_finger_bone(name):
    if _is_roll_bone(name): return False
    base, side = _split_finger_side(name)
    if side is None: return False
    if _get_finger_prefix(base) is None: return False
    if any(e in base.lower() for e in EXCLUDE_SUBSTRINGS): return False
    return True

def _is_thumb(name):            return "thumb" in name.lower()
def _get_roll(name):            return ROLL_THUMB if _is_thumb(name) else ROLL_FINGERS

def _make_roll_name(original):
    base, side = _split_finger_side(original)
    return (base + "_roll" + side) if side else (original + "_roll")

def _segment_key(name):
    base, _ = _split_finger_side(name)
    nums = re.findall(r'\d+', base)
    return int(nums[-1]) if nums else 0

def _group_finger_bones(bone_names):
    groups = defaultdict(list)
    for name in bone_names:
        base, side = _split_finger_side(name)
        prefix = _get_finger_prefix(base)
        if prefix and side:
            groups[(prefix, side.lower())].append(name)
    for key in groups:
        groups[key].sort(key=_segment_key)
    return groups

def _apply_finger_offset(bone, name):
    if _is_thumb(name):
        bone.head.y += Y_OFFSET; bone.tail.y += Y_OFFSET
    else:
        bone.head.z += Z_OFFSET; bone.tail.z += Z_OFFSET


def run_finger_controller(obj):
    arm = obj.data
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = arm.edit_bones

    finger_names = [b.name for b in edit_bones if _is_finger_bone(b.name)]
    if not finger_names:
        bpy.ops.object.mode_set(mode='POSE')
        raise RuntimeError("No finger bones found.")

    groups = _group_finger_bones(finger_names)
    roll_map = {}
    for (prefix, side), sorted_names in groups.items():
        for src_name in sorted_names:
            roll_name = _make_roll_name(src_name)
            roll_map[src_name] = roll_name
            if roll_name in edit_bones:
                continue
            src = edit_bones[src_name]
            nb = edit_bones.new(roll_name)
            nb.head = src.head.copy(); nb.tail = src.tail.copy()
            nb.matrix = src.matrix.copy(); nb.use_connect = False
            _apply_finger_offset(nb, roll_name)
            nb.roll = _get_roll(roll_name)

    for (prefix, side), sorted_names in groups.items():
        for i, src_name in enumerate(sorted_names):
            rn = roll_map[src_name]
            if rn not in edit_bones: continue
            rb = edit_bones[rn]
            if i == 0:
                rb.parent = edit_bones[src_name].parent
            else:
                prev = roll_map[sorted_names[i-1]]
                if prev in edit_bones: rb.parent = edit_bones[prev]
            rb.use_connect = False

    for name in finger_names:
        if name in edit_bones:
            edit_bones[name].roll = _get_roll(name)

    bpy.ops.object.mode_set(mode='POSE')

    # Locks on roll[0]
    for (prefix, side), sorted_names in groups.items():
        first = roll_map.get(sorted_names[0])
        if not first: continue
        pb = obj.pose.bones.get(first)
        if pb is None: continue
        pb.lock_location = (True, True, True)
        pb.lock_scale    = (True, True, True)
        pb.lock_rotation = (False, True, True) if _is_thumb(first) else (True, True, False)

    # Copy Rotation: roll[i] → roll[i-1] (Replace)
    for (prefix, side), sorted_names in groups.items():
        chain = [roll_map[n] for n in sorted_names if roll_map.get(n) in obj.pose.bones]
        for i in range(1, len(chain)):
            pb = obj.pose.bones[chain[i]]
            tgt = chain[i-1]
            for c in list(pb.constraints):
                if c.type == "COPY_ROTATION" and c.subtarget == tgt:
                    pb.constraints.remove(c)
            con = pb.constraints.new("COPY_ROTATION")
            con.target = obj; con.subtarget = tgt
            con.mix_mode = "REPLACE"
            con.target_space = "LOCAL_OWNER_ORIENT"; con.owner_space = "LOCAL"

    # Copy Rotation: original → _roll (Add)
    for (prefix, side), sorted_names in groups.items():
        for src_name in sorted_names:
            rn = roll_map.get(src_name)
            if not rn or src_name not in obj.pose.bones: continue
            pb = obj.pose.bones[src_name]
            for c in list(pb.constraints):
                if c.type == "COPY_ROTATION" and c.subtarget == rn:
                    pb.constraints.remove(c)
            con = pb.constraints.new("COPY_ROTATION")
            con.target = obj; con.subtarget = rn
            con.mix_mode = "ADD"
            con.target_space = "LOCAL_OWNER_ORIENT"; con.owner_space = "LOCAL"

    # Hide roll[1+] via Bone Collection
    HIDDEN_COLL = "_roll_hidden"
    coll = arm.collections.get(HIDDEN_COLL) or arm.collections.new(HIDDEN_COLL)
    coll.is_visible = False
    for (prefix, side), sorted_names in groups.items():
        chain = [roll_map[n] for n in sorted_names if roll_map.get(n)]
        for bn in chain[1:]:
            bone = arm.bones.get(bn)
            if bone: coll.assign(bone)

    # Widgets
    def assign_widget(pb, shape):
        bpy.ops.pose.select_all(action='DESELECT')
        pb.select = True; obj.data.bones.active = pb.bone
        try:
            bpy.context.window_manager.widget_list = shape
            with bpy.context.temp_override(active_object=obj, object=obj,
                    active_pose_bone=pb, selected_pose_bones=[pb]):
                bpy.ops.bonewidget.create_widget()
        except Exception as e:
            print(f"  [widget] Error '{pb.name}': {e}")

    for (prefix, side), sorted_names in groups.items():
        chain = [roll_map[n] for n in sorted_names if roll_map.get(n) in obj.pose.bones]
        if not chain: continue
        assign_widget(obj.pose.bones[chain[0]], "Sphere")
        if _is_thumb(chain[0]) and len(chain) > 1:
            assign_widget(obj.pose.bones[chain[1]], "Arrow Double (straight)")

    # Color
    for (prefix, side), sorted_names in groups.items():
        chain = [roll_map[n] for n in sorted_names if roll_map.get(n) in obj.pose.bones]
        for rn in chain:
            obj.pose.bones[rn].color.palette = 'THEME01'

    print("[finger] Done.")
    return roll_map, groups


# ─────────────────────────────────────────────────────────────────────────────
#  HAND CONTROLLER LOGIC
# ─────────────────────────────────────────────────────────────────────────────

HAND_CONTROL_LEN      = 0.03
HAND_CONTROL_Z_OFFSET = 0.04
BONE_CONFIGS          = [("_L", ".l", 1), ("_R", ".r", -1)]
BONE_BASE_NAME        = "hand_control"
WIDGET_SHAPE          = "Root 1"
WIDGET_ROT_X          = math.radians(0)
WIDGET_ROT_Y          = math.radians(90)
WIDGET_ROT_Z          = math.radians(90)
WIDGET_WIRE_WIDTH     = 2.00


def P(action, constraint, expr, ttype, rot_mode=None):
    return dict(action=action, constraint=constraint, expr=expr, type=ttype, rot_mode=rot_mode)

ACTION_CONSTRAINT_MAP = {
    ".l": {
        "ctrl": "hand_control_L",
        "groups": [
            {"bones": ["c_pinky1_roll","c_ring1_roll","c_middle1_roll","c_index1_roll","c_thumb2_roll"],
             "pairs": [P("fist.l","Action_fist.l","max(0.0, min(1.0, var / -0.03))","LOC_X"),
                       P("extend.l","Action_extend.l","max(0.0, min(1.0, var /  0.03))","LOC_X")]},
            {"bones": ["c_thumb1"],
             "pairs": [P("fist.l","Action_fist.l","max(0.0, min(1.0, var / -0.03))","LOC_X"),
                       P("extend.l","Action_extend.l","max(0.0, min(1.0, var /  0.03))","LOC_X"),
                       P("roll.l","Action_roll.l","max(0.0, min(1.0, var / -0.500))","ROT_X","QUATERNION"),
                       P("roll2.l","Action_roll2.l","max(0.0, min(1.0, var /  0.500))","ROT_X","QUATERNION"),
                       P("adduction.l","Action_adduction.l","max(0.0, min(1.0, (var - 1.0) / -0.4))","SCALE_Z"),
                       P("abduction.l","Action_abduction.l","max(0.0, min(1.0, (var - 1.0) /  0.3))","SCALE_Z")]},
            {"bones": ["c_index1","c_middle1","c_ring1","c_pinky1"],
             "pairs": [P("roll.l","Action_roll.l","max(0.0, min(1.0, var / -0.500))","ROT_X","QUATERNION"),
                       P("roll2.l","Action_roll2.l","max(0.0, min(1.0, var /  0.500))","ROT_X","QUATERNION"),
                       P("adduction.l","Action_adduction.l","max(0.0, min(1.0, (var - 1.0) / -0.4))","SCALE_Z"),
                       P("abduction.l","Action_abduction.l","max(0.0, min(1.0, (var - 1.0) /  0.3))","SCALE_Z")]},
            {"bones": ["c_index2","c_index3","c_middle2","c_middle3","c_ring2","c_ring3","c_pinky2","c_pinky3","c_thumb3"],
             "pairs": [P("claw.l","Action_claw.l","max(0.0, min(1.0, (var - 1.0) / -0.4))","SCALE_X")]},
        ],
    },
    ".r": {
        "ctrl": "hand_control_R",
        "groups": [
            {"bones": ["c_pinky1_roll","c_ring1_roll","c_middle1_roll","c_index1_roll","c_thumb2_roll"],
             "pairs": [P("fist.r","Action_fist.r","max(0.0, min(1.0, var /  0.03))","LOC_X"),
                       P("extend.r","Action_extend.r","max(0.0, min(1.0, var / -0.03))","LOC_X")]},
            {"bones": ["c_thumb1"],
             "pairs": [P("fist.r","Action_fist.r","max(0.0, min(1.0, var /  0.03))","LOC_X"),
                       P("extend.r","Action_extend.r","max(0.0, min(1.0, var / -0.03))","LOC_X"),
                       P("roll.r","Action_roll.r","max(0.0, min(1.0, var /  0.500))","ROT_X","QUATERNION"),
                       P("roll2.r","Action_roll2.r","max(0.0, min(1.0, var / -0.500))","ROT_X","QUATERNION"),
                       P("adduction.r","Action_adduction.r","max(0.0, min(1.0, (var - 1.0) / -0.4))","SCALE_Z"),
                       P("abduction.r","Action_abduction.r","max(0.0, min(1.0, (var - 1.0) /  0.3))","SCALE_Z")]},
            {"bones": ["c_index1","c_middle1","c_ring1","c_pinky1"],
             "pairs": [P("roll.r","Action_roll.r","max(0.0, min(1.0, var / -0.500))","ROT_X","QUATERNION"),
                       P("roll2.r","Action_roll2.r","max(0.0, min(1.0, var /  0.500))","ROT_X","QUATERNION"),
                       P("adduction.r","Action_adduction.r","max(0.0, min(1.0, (var - 1.0) / -0.4))","SCALE_Z"),
                       P("abduction.r","Action_abduction.r","max(0.0, min(1.0, (var - 1.0) /  0.3))","SCALE_Z")]},
            {"bones": ["c_index2","c_index3","c_middle2","c_middle3","c_ring2","c_ring3","c_pinky2","c_pinky3","c_thumb3"],
             "pairs": [P("claw.r","Action_claw.r","max(0.0, min(1.0, (var - 1.0) / -0.4))","SCALE_X")]},
        ],
    },
}


def make_action_constraint(pb, armature_obj, action, constr_name,
                            expr, transform_type, rotation_mode=None,
                            hand_control_bone=None):
    if constr_name in pb.constraints:
        pb.constraints.remove(pb.constraints[constr_name])
    con = pb.constraints.new('ACTION')
    con.name = constr_name; con.target = armature_obj
    con.subtarget = ""; con.action = action
    if hasattr(action,'slots') and action.slots and hasattr(con,'slot'):
        try: con.slot = action.slots[0]
        except Exception: pass
    safe_set(con,'frame_start',0); safe_set(con,'frame_end',10)
    con.influence = 1.0
    for mix_val in ('BEFORE_SPLIT','BEFORE'):
        try: con.mix_mode = mix_val; break
        except (TypeError,AttributeError): continue
    safe_set(con,'use_split_channels',True)
    channel_map = {'LOC_X':('LOCATION_X','LOC_X'),'ROT_X':('ROTATION_X','ROT_X'),
                   'SCALE_X':('SCALE_X',),'SCALE_Z':('SCALE_Z',)}
    for cv in channel_map.get(transform_type,(transform_type,)):
        try: con.transform_channel = cv; break
        except (TypeError,AttributeError): continue
    for sv in ('LOCAL_OWNER_ORIENT','LOCAL_WITH_PARENT','LOCAL'):
        try: con.target_space = sv; break
        except (TypeError,AttributeError): continue
    for a in ('range_min','min'): safe_set(con,a,0.0)
    for a in ('range_max','max'): safe_set(con,a,1.0)
    for a in ('use_evaluation_time','use_eval_time'):
        if hasattr(con,a):
            try: setattr(con,a,True); break
            except Exception: pass
    if expr and hand_control_bone:
        bone_name = pb.name
        driver_path = f'pose.bones["{bone_name}"].constraints["{constr_name}"].eval_time'
        try: armature_obj.driver_remove(driver_path)
        except Exception: pass
        try:
            fc_drv = armature_obj.driver_add(driver_path)
            drv = fc_drv.driver; drv.type='SCRIPTED'; drv.expression=expr
            for v in list(drv.variables): drv.variables.remove(v)
            v=drv.variables.new(); v.name='var'; v.type='TRANSFORMS'
            tgt=v.targets[0]; tgt.id=armature_obj
            tgt.bone_target=hand_control_bone
            tgt.transform_type=transform_type; tgt.transform_space='LOCAL_SPACE'
            if rotation_mode and hasattr(tgt,'rotation_mode'):
                try: tgt.rotation_mode=rotation_mode
                except Exception: pass
        except Exception as e:
            print(f"  [driver] Error '{constr_name}': {e}")
    return con


def run_hand_controller(obj):
    arm = obj.data
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = arm.edit_bones
    created_bones = []

    for bone_suffix, parent_suffix, x_sign in BONE_CONFIGS:
        bone_name   = BONE_BASE_NAME + bone_suffix
        parent_name = "hand" + parent_suffix
        if bone_name in edit_bones:
            edit_bones.remove(edit_bones[bone_name])
        eb = edit_bones.new(bone_name)
        ik_name = "c_hand_ik" + parent_suffix
        ik_bone = edit_bones.get(ik_name)
        if ik_bone:
            mid = (ik_bone.head + ik_bone.tail) / 2.0
            cx,cy,cz = mid.x, mid.y, mid.z + HAND_CONTROL_Z_OFFSET
        else:
            hb = edit_bones.get(parent_name)
            if hb:
                mid = (hb.head + hb.tail) / 2.0
                cx,cy,cz = mid.x, mid.y, mid.z + HAND_CONTROL_Z_OFFSET
            else:
                cx=cy=cz=0.0
        eb.head = (cx, cy, cz); eb.tail = (cx, cy, cz + HAND_CONTROL_LEN)
        eb.use_connect = False
        if parent_name in edit_bones:
            eb.parent = edit_bones[parent_name]
        created_bones.append(bone_name)

    bpy.ops.object.mode_set(mode='POSE')
    for bone_name in created_bones:
        pb = obj.pose.bones.get(bone_name)
        if pb is None: continue
        pb.lock_location=(False,True,True); pb.lock_scale=(False,True,False)
        pb.lock_rotation=(False,True,True); pb.color.palette='THEME12'
        try:
            bpy.ops.pose.select_all(action='DESELECT')
            pb.select=True; obj.data.bones.active=pb.bone
            bpy.context.window_manager.widget_list=WIDGET_SHAPE
            with bpy.context.temp_override(active_object=obj,object=obj,
                    active_pose_bone=pb,selected_pose_bones=[pb]):
                bpy.ops.bonewidget.create_widget(relative_size=True,
                    global_size_simple=1.00,slide_simple=0.00,
                    rotation=(WIDGET_ROT_X,WIDGET_ROT_Y,WIDGET_ROT_Z),
                    wireframe_width=WIDGET_WIRE_WIDTH)
        except Exception as e:
            print(f"  [hand] Widget error {bone_name}: {e}")
        for c in list(pb.constraints):
            if c.type in ("LIMIT_LOCATION","LIMIT_ROTATION","LIMIT_SCALE"):
                pb.constraints.remove(c)
        ll=pb.constraints.new("LIMIT_LOCATION")
        ll.use_min_x=True; ll.min_x=-0.03; ll.use_min_y=True; ll.min_y=-0.05
        ll.use_max_x=True; ll.max_x=0.03;  ll.use_max_y=True; ll.max_y=0.05
        ll.use_transform_limit=True; ll.owner_space='LOCAL'; ll.influence=1.0
        lr=pb.constraints.new("LIMIT_ROTATION")
        lr.use_limit_x=True; lr.min_x=math.radians(-35); lr.max_x=math.radians(35)
        lr.euler_order='AUTO'; lr.use_transform_limit=True
        lr.owner_space='LOCAL'; lr.influence=1.0
        safe_set(lr,'use_legacy_behavior',True)
        ls=pb.constraints.new("LIMIT_SCALE")
        ls.use_min_x=True; ls.min_x=0.6; ls.use_min_z=True; ls.min_z=0.6
        ls.use_max_x=True; ls.max_x=1.0; ls.use_max_z=True; ls.max_z=1.3
        ls.use_transform_limit=True; ls.owner_space='LOCAL'; ls.influence=1.0

    try:
        actions_data = load_actions_data()
        recreate_actions(actions_data)
    except Exception as e:
        print(f"  [hand] Error loading actions: {e}")

    pose_bones = obj.pose.bones
    for side, side_data in ACTION_CONSTRAINT_MAP.items():
        ctrl_bone = side_data["ctrl"]
        for group in side_data["groups"]:
            for bone_base in group["bones"]:
                full_name = bone_base + side
                pb = pose_bones.get(full_name)
                if pb is None: continue
                for pair in group["pairs"]:
                    action = bpy.data.actions.get(pair["action"])
                    if action is None: continue
                    make_action_constraint(pb=pb, armature_obj=obj, action=action,
                        constr_name=pair["constraint"], expr=pair["expr"],
                        transform_type=pair["type"], rotation_mode=pair.get("rot_mode"),
                        hand_control_bone=ctrl_bone)
    print(f"[hand] Done. Bones: {created_bones}")


# ─────────────────────────────────────────────────────────────────────────────
#  EAR ROLL LOGIC
# ─────────────────────────────────────────────────────────────────────────────

EAR_PREFIX = "Ear_"
EAR_SIDES  = ["_L", "_R"]

def _split_ear_side(name):
    for side in EAR_SIDES:
        if name.endswith(side):
            return name[:-len(side)], side
    return name, None

def _is_ear_bone(name):
    if "_roll" in name.lower(): return False
    base, side = _split_ear_side(name)
    return side is not None and base.startswith(EAR_PREFIX)

def _make_ear_roll_name(original):
    base, side = _split_ear_side(original)
    return (base + "_roll" + side) if side else (original + "_roll")

def _ear_segment_key(name):
    base, _ = _split_ear_side(name)
    nums = re.findall(r'\d+', base)
    return int(nums[-1]) if nums else 0


def run_ear_controller(obj):
    arm = obj.data
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = arm.edit_bones

    ear_names = [b.name for b in edit_bones if _is_ear_bone(b.name)]
    if not ear_names:
        bpy.ops.object.mode_set(mode='POSE')
        raise RuntimeError("No ear bones found (Ear_NN_L / Ear_NN_R).")

    groups = {side: [] for side in EAR_SIDES}
    for name in ear_names:
        _, side = _split_ear_side(name)
        if side: groups[side].append(name)
    for side in groups:
        groups[side].sort(key=_ear_segment_key)

    roll_map = {}
    for side, sorted_names in groups.items():
        for src_name in sorted_names:
            rn = _make_ear_roll_name(src_name)
            roll_map[src_name] = rn
            if rn in edit_bones: continue
            src = edit_bones[src_name]
            nb = edit_bones.new(rn)
            nb.head=src.head.copy(); nb.tail=src.tail.copy()
            nb.matrix=src.matrix.copy(); nb.roll=src.roll; nb.use_connect=False

    for side, sorted_names in groups.items():
        for i, src_name in enumerate(sorted_names):
            rn = roll_map[src_name]
            if rn not in edit_bones: continue
            rb = edit_bones[rn]
            if i == 0:
                if "head.x" in edit_bones:
                    rb.parent = edit_bones["head.x"]
            else:
                prev = roll_map[sorted_names[i-1]]
                if prev in edit_bones: rb.parent = edit_bones[prev]
            rb.use_connect = False

    bpy.ops.object.mode_set(mode='POSE')

    # Copy Rotation cascade (Replace)
    for side, sorted_names in groups.items():
        chain = [roll_map[n] for n in sorted_names if roll_map.get(n) in obj.pose.bones]
        for i in range(1, len(chain)):
            pb = obj.pose.bones[chain[i]]; tgt = chain[i-1]
            for c in list(pb.constraints):
                if c.type=="COPY_ROTATION" and c.subtarget==tgt: pb.constraints.remove(c)
            con = pb.constraints.new("COPY_ROTATION")
            con.target=obj; con.subtarget=tgt; con.mix_mode="REPLACE"
            con.target_space="LOCAL_OWNER_ORIENT"; con.owner_space="LOCAL"

    # Copy Rotation original → roll (Add)
    for side, sorted_names in groups.items():
        for src_name in sorted_names:
            rn = roll_map.get(src_name)
            if not rn or src_name not in obj.pose.bones: continue
            pb = obj.pose.bones[src_name]
            for c in list(pb.constraints):
                if c.type=="COPY_ROTATION" and c.subtarget==rn: pb.constraints.remove(c)
            con = pb.constraints.new("COPY_ROTATION")
            con.target=obj; con.subtarget=rn; con.mix_mode="ADD"
            con.target_space="LOCAL_OWNER_ORIENT"; con.owner_space="LOCAL"

    # Widget Roll 1 on roll[0]
    for side, sorted_names in groups.items():
        rz = roll_map.get(sorted_names[0])
        if not rz or rz not in obj.pose.bones: continue
        pb = obj.pose.bones[rz]
        bpy.ops.pose.select_all(action='DESELECT')
        pb.select=True; obj.data.bones.active=pb.bone
        mirror = -1 if side=="_R" else 1
        try:
            bpy.context.window_manager.widget_list="Roll 1"
            with bpy.context.temp_override(active_object=obj,object=obj,
                    active_pose_bone=pb,selected_pose_bones=[pb]):
                bpy.ops.bonewidget.create_widget(relative_size=True,
                    global_size_simple=1.00,slide_simple=0.00,
                    rotation=(math.radians(-9*mirror),math.radians(0),math.radians(-18*mirror)),
                    wireframe_width=2.00)
        except Exception as e:
            print(f"  [ear] Widget error: {e}")

    # Hide roll[1+]
    HIDDEN_COLL="_roll_hidden"
    coll = arm.collections.get(HIDDEN_COLL) or arm.collections.new(HIDDEN_COLL)
    coll.is_visible=False
    for side, sorted_names in groups.items():
        chain=[roll_map[n] for n in sorted_names if roll_map.get(n)]
        for bn in chain[1:]:
            bone=arm.bones.get(bn)
            if bone: coll.assign(bone)

    print("[ear] Done.")


# ─────────────────────────────────────────────────────────────────────────────
#  CLEANUP LOGIC
# ─────────────────────────────────────────────────────────────────────────────

ACTION_NAMES = [
    "fist.l","fist.r","extend.l","extend.r","roll.l","roll.r",
    "roll2.l","roll2.r","adduction.l","adduction.r",
    "abduction.l","abduction.r","claw.l","claw.r",
]
ACTION_CONSTRAINT_NAMES = [
    "Action_fist.l","Action_fist.r","Action_extend.l","Action_extend.r",
    "Action_roll.l","Action_roll.r","Action_roll2.l","Action_roll2.r",
    "Action_adduction.l","Action_adduction.r","Action_abduction.l","Action_abduction.r",
    "Action_claw.l","Action_claw.r",
]
HAND_CONTROL_BONES = ["hand_control_L", "hand_control_R"]


def _is_finger_base(name):
    prefixes = ["c_thumb","c_index","c_middle","c_ring","c_pinky"]
    sides    = [".l",".r"]
    lower = name.lower()
    return (any(lower.startswith(p) for p in prefixes) and
            any(lower.endswith(s) for s in sides))


def _is_ear_roll(name):
    return "_roll" in name.lower() and name.startswith("Ear_")


def run_cleanup(obj):
    arm = obj.data
    bpy.ops.object.mode_set(mode='POSE')
    removed_constraints = removed_drivers = 0

    for pb in obj.pose.bones:
        # Action constraints + their drivers
        for c in list(pb.constraints):
            if c.name in ACTION_CONSTRAINT_NAMES:
                dp = f'pose.bones["{pb.name}"].constraints["{c.name}"].eval_time'
                try: obj.driver_remove(dp); removed_drivers+=1
                except Exception: pass
                pb.constraints.remove(c); removed_constraints+=1
        # Copy Rotation on finger/roll bones
        if _is_finger_base(pb.name) or _is_roll_bone(pb.name):
            for c in list(pb.constraints):
                if c.type=="COPY_ROTATION":
                    pb.constraints.remove(c); removed_constraints+=1
        # Copy Rotation on ear bones
        if pb.name.startswith("Ear_"):
            for c in list(pb.constraints):
                if c.type=="COPY_ROTATION":
                    pb.constraints.remove(c); removed_constraints+=1
        # Limit constraints on hand_control
        if pb.name in HAND_CONTROL_BONES:
            for c in list(pb.constraints):
                if c.type in ("LIMIT_LOCATION","LIMIT_ROTATION","LIMIT_SCALE"):
                    pb.constraints.remove(c); removed_constraints+=1

    print(f"  [cleanup] Constraints: {removed_constraints}  Drivers: {removed_drivers}")

    # Remove bones
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = arm.edit_bones
    to_remove = ([b.name for b in edit_bones if _is_roll_bone(b.name)] +
                 [b for b in HAND_CONTROL_BONES if b in edit_bones])
    for bn in to_remove:
        if bn in edit_bones:
            edit_bones.remove(edit_bones[bn])
            print(f"  [cleanup] Bone removed: {bn}")

    # Remove bone collection
    coll = arm.collections.get("_roll_hidden")
    if coll: arm.collections.remove(coll)

    # Remove actions
    bpy.ops.object.mode_set(mode='POSE')
    for aname in ACTION_NAMES:
        a = bpy.data.actions.get(aname)
        if a:
            a.use_fake_user=False
            if a.users==0: bpy.data.actions.remove(a)


# ─────────────────────────────────────────────────────────────────────────────
#  SKELETON CLEANUP (handle + Sp_He_Ear0_*)
# ─────────────────────────────────────────────────────────────────────────────

def run_skeleton_cleanup(obj):
    arm = obj.data
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = arm.edit_bones

    to_remove = []
    for b in edit_bones:
        n = b.name
        if n.lower().endswith("handle") or re.match(r'^Sp_He_Ear0_', n):
            to_remove.append(n)

    removed = 0
    for bn in to_remove:
        if bn in edit_bones:
            edit_bones.remove(edit_bones[bn])
            removed += 1
            print(f"  [skel_cleanup] Removed: {bn}")

    bpy.ops.object.mode_set(mode='POSE')
    print(f"  [skel_cleanup] {removed} bones removed.")
    return removed


# ─────────────────────────────────────────────────────────────────────────────
#  SHAPE KEYS COMBINER LOGIC
# ─────────────────────────────────────────────────────────────────────────────

SEPARATOR_NAME = "==== both ===="

def run_shape_keys_combiner(obj):
    if not obj or not obj.data.shape_keys:
        raise RuntimeError("No object with shape keys found.")

    shape_keys = obj.data.shape_keys.key_blocks
    pairs = {}

    for sk in shape_keys:
        name = sk.name
        if 'xrange' in name.lower() or 'yrange' in name.lower(): continue
        if '_R(' in name or '_R[' in name or name.endswith('_R'):
            base = (name.replace('_R','',1) if name.endswith('_R')
                    else name.replace('_R(','(').replace('_R[','['))
            pairs.setdefault(base,{})['R'] = sk
        elif '_L(' in name or '_L[' in name or name.endswith('_L'):
            base = (name.replace('_L','',1) if name.endswith('_L')
                    else name.replace('_L(','(').replace('_L[','['))
            pairs.setdefault(base,{})['L'] = sk

    valid_pairs = {k:v for k,v in pairs.items() if 'L' in v and 'R' in v}
    if not valid_pairs:
        raise RuntimeError("No _L/_R pairs found.")

    if SEPARATOR_NAME not in shape_keys:
        sep = obj.shape_key_add(name=SEPARATOR_NAME, from_mix=False)
        sep.value=0.0; sep.mute=True; sep.lock_shape=True
        sep.slider_min=0.0; sep.slider_max=0.0

    created = 0
    for base_name, pair in valid_pairs.items():
        if base_name in shape_keys: continue
        obj.shape_key_add(name=base_name, from_mix=False)
        new_sk = shape_keys[base_name]; new_sk.value=0.0
        sk_l=pair['L']; sk_r=pair['R']; basis=shape_keys[0]
        for i,_ in enumerate(obj.data.vertices):
            dl = sk_l.data[i].co - basis.data[i].co
            dr = sk_r.data[i].co - basis.data[i].co
            new_sk.data[i].co = basis.data[i].co + dl + dr
        created+=1
        print(f"  [shape_keys] Created: {base_name}")
    print(f"[shape_keys] {created} key(s) created.")
    return created


# ─────────────────────────────────────────────────────────────────────────────
#  EYE RIG LOGIC (from original uma_rig_ui.py)
# ─────────────────────────────────────────────────────────────────────────────

EYE_CTRL_BONE        = "eye.ctrl"
EYE_CTRL_PARENT      = "head.x"
EYE_LOCATOR_L        = "Eye_locator_L"
EYE_LOCATOR_R        = "Eye_locator_R"
EYE_TARGET_LOC_L     = "Eye_target_locator_L"
EYE_TARGET_LOC_R     = "Eye_target_locator_R"
SK_XRANGE_L          = "Eye_20_L(XRange)[M_Face]"
SK_XRANGE_R          = "Eye_20_R(XRange)[M_Face]"
SK_YRANGE_L          = "Eye_21_L(YRange)[M_Face]"
SK_YRANGE_R          = "Eye_21_R(YRange)[M_Face]"
SK_CLOSE_L           = "Eye_2_L(CloseA)[M_Face]"
SK_CLOSE_R           = "Eye_2_R(CloseA)[M_Face]"
SK_ODOROKI_L         = "Eye_12_L(OdorokiA)[M_Face]"
SK_ODOROKI_R         = "Eye_12_R(OdorokiA)[M_Face]"
LIMIT_SCALE_MIN      = 0.8
LIMIT_SCALE_MAX      = 1.2
DAMPED_TRACK_AXIS    = 'TRACK_Z'
EYE_SIDE_OFFSET      = 0.03
EYE_CTRL_BONE_LENGTH = 0.05
ALLOWED_EXPR_CHARS   = re.compile(r'^[0-9a-zA-Z_\+\-\*/\(\)\.\,\s<>=!&|%^~]+$')
DANGEROUS_KEYWORDS   = ("import","exec","eval","open","os","__","globals",
                         "locals","getattr","setattr","delattr","compile",
                         "input","print","exit","quit","breakpoint")

def validate_expression(expr):
    expr=expr.strip()
    if not expr: return False,"Expression cannot be empty."
    if len(expr)>256: return False,"Expression too long."
    low=expr.lower()
    for kw in DANGEROUS_KEYWORDS:
        if kw in low: return False,f"Forbidden keyword: '{kw}'"
    if not ALLOWED_EXPR_CHARS.match(expr): return False,"Invalid characters."
    if "var" not in expr: return False,"Expression must reference 'var'."
    try:
        compile(expr,"<expr>","eval")
        result=eval(compile(expr,"<expr>","eval"),{"__builtins__":{}},
                    {"var":0.5,"min":min,"max":max,"abs":abs,"round":round})
        if not isinstance(result,(int,float)): return False,"Must evaluate to a number."
    except SyntaxError as e: return False,f"Syntax error: {e.msg}"
    except Exception as ex:  return False,f"Runtime error: {ex}"
    return True,""

def _add_limit_scale_eye(pb):
    for c in list(pb.constraints):
        if c.type=='LIMIT_SCALE': pb.constraints.remove(c)
    ls=pb.constraints.new('LIMIT_SCALE')
    for a in ('min_x','min_y','min_z'):
        setattr(ls,'use_'+a,True); setattr(ls,a,LIMIT_SCALE_MIN)
    for a in ('max_x','max_y','max_z'):
        setattr(ls,'use_'+a,True); setattr(ls,a,LIMIT_SCALE_MAX)
    ls.owner_space='LOCAL'

def _create_eye_ctrl_bone(arm_obj):
    bpy.context.view_layer.objects.active=arm_obj
    bpy.ops.object.mode_set(mode='EDIT')
    eb=arm_obj.data.edit_bones
    if EYE_CTRL_BONE in eb: eb.remove(eb[EYE_CTRL_BONE])
    loc_l=eb.get(EYE_LOCATOR_L); loc_r=eb.get(EYE_LOCATOR_R)
    if loc_l and loc_r:
        ctrl_head=(loc_l.head+loc_r.head)/2+mathutils.Vector((0,-0.15,0))
    else:
        head_eb=eb.get(EYE_CTRL_PARENT)
        ctrl_head=(head_eb.head+mathutils.Vector((0,-0.15,0.05))
                   if head_eb else mathutils.Vector((0,-0.15,1.3)))
    nb=eb.new(EYE_CTRL_BONE); nb.head=ctrl_head
    nb.tail=ctrl_head+mathutils.Vector((0,0,EYE_CTRL_BONE_LENGTH)); nb.use_deform=False
    parent_eb=eb.get(EYE_CTRL_PARENT)
    if parent_eb: nb.parent=parent_eb; nb.use_connect=False
    bpy.ops.object.mode_set(mode='POSE')
    pb=arm_obj.pose.bones.get(EYE_CTRL_BONE)
    if pb: _add_limit_scale_eye(pb)

def _reposition_eye_targets(arm_obj):
    bpy.context.view_layer.objects.active=arm_obj
    bpy.ops.object.mode_set(mode='EDIT')
    eb=arm_obj.data.edit_bones
    ctrl_eb=eb.get(EYE_CTRL_BONE)
    if ctrl_eb is None: bpy.ops.object.mode_set(mode='POSE'); return
    ctrl_pos=ctrl_eb.head.copy()
    for bn,sx in [(EYE_TARGET_LOC_L,EYE_SIDE_OFFSET),(EYE_TARGET_LOC_R,-EYE_SIDE_OFFSET)]:
        bone=eb.get(bn)
        if not bone: continue
        nh=ctrl_pos+mathutils.Vector((sx,0,0))
        bone.head=nh; bone.tail=nh+mathutils.Vector((0,0,EYE_CTRL_BONE_LENGTH))
        bone.parent=ctrl_eb; bone.use_connect=False
    bpy.ops.object.mode_set(mode='POSE')

def _setup_eye_locator(arm_obj,loc_bone,tgt_bone):
    bpy.context.view_layer.objects.active=arm_obj
    bpy.ops.object.mode_set(mode='POSE')
    pb=arm_obj.pose.bones.get(loc_bone)
    if pb is None: bpy.ops.object.mode_set(mode='OBJECT'); return
    for c in list(pb.constraints):
        if c.type in ('DAMPED_TRACK','COPY_SCALE','LIMIT_SCALE'): pb.constraints.remove(c)
    dt=pb.constraints.new('DAMPED_TRACK')
    dt.name="Damped Track"; dt.target=arm_obj; dt.subtarget=tgt_bone; dt.track_axis=DAMPED_TRACK_AXIS
    cs=pb.constraints.new('COPY_SCALE')
    cs.name="Copy Scale"; cs.target=arm_obj; cs.subtarget=EYE_CTRL_BONE
    cs.use_x=cs.use_y=cs.use_z=True; cs.use_offset=False
    cs.target_space=cs.owner_space='LOCAL'
    _add_limit_scale_eye(pb)

def _remove_driver(shape_keys,sk_name):
    if not shape_keys.animation_data: return
    fc=shape_keys.animation_data.drivers.find(f'key_blocks["{sk_name}"].value')
    if fc: shape_keys.animation_data.drivers.remove(fc)

def _setup_rotation_driver(face_mesh,arm_obj,sk_name,bone_name,rot_axis,expression,smin,smax):
    sk=face_mesh.data.shape_keys
    if not sk or sk_name not in sk.key_blocks: return
    sk.animation_data_create(); _remove_driver(sk,sk_name)
    kb=sk.key_blocks[sk_name]; kb.slider_min=smin; kb.slider_max=smax
    drv=kb.driver_add("value").driver; drv.type='SCRIPTED'
    v=drv.variables.new(); v.name,v.type="var",'TRANSFORMS'
    t=v.targets[0]; t.id,t.bone_target=arm_obj,bone_name
    t.transform_type=['ROT_X','ROT_Y','ROT_Z'][rot_axis]
    t.transform_space,t.rotation_mode='LOCAL_SPACE','AUTO'
    drv.expression=expression

def _setup_scale_driver(face_mesh,arm_obj,sk_name,loc_bone,expression):
    sk=face_mesh.data.shape_keys
    if not sk or sk_name not in sk.key_blocks: return
    sk.animation_data_create(); _remove_driver(sk,sk_name)
    drv=sk.key_blocks[sk_name].driver_add("value").driver; drv.type='SCRIPTED'
    v=drv.variables.new(); v.name,v.type="var",'TRANSFORMS'
    t=v.targets[0]; t.id,t.bone_target=arm_obj,loc_bone
    t.transform_type,t.transform_space='SCALE_AVG','LOCAL_SPACE'
    drv.expression=expression

def _term_matches_prefix(bone_name_lower,term):
    parts=re.split(r'[_.\s]',bone_name_lower)
    return any(part.startswith(term) for part in parts)

def _setup_bone_collections(arm_obj,bone_coll_prop,remove_from_main=True):
    arm=arm_obj.data; collections=arm.collections
    coll_dict={}
    for entry in bone_coll_prop:
        name=entry.coll_name.strip()
        terms=[t.strip().lower() for t in entry.terms.split(",") if t.strip()]
        if name and terms: coll_dict[name]=terms
    coll_map={}
    for name in coll_dict:
        if name in collections: collections.remove(collections[name])
        coll_map[name]=collections.new(name)
    main_coll=collections.get("Main") if remove_from_main else None
    counts={name:0 for name in coll_dict}
    for bone in arm.bones:
        bnl=bone.name.lower()
        for cn,terms in coll_dict.items():
            if any(_term_matches_prefix(bnl,t) for t in terms):
                coll_map[cn].assign(bone); counts[cn]+=1
                if main_coll:
                    try: main_coll.unassign(bone)
                    except Exception: pass
                break
    return counts


# ─────────────────────────────────────────────────────────────────────────────
#  PROPERTY GROUPS
# ─────────────────────────────────────────────────────────────────────────────

class UmaBoneCollEntry(PropertyGroup):
    coll_name: StringProperty(name="Name", default="New Collection")
    terms:     StringProperty(name="Keywords", default="keyword")

_DEFAULT_COLLECTIONS = [
    ("Hair","hair, ear, tail"), ("Cloth","shirt, jacket, skirt, ribbon, mantle, cloth, acc, sleeve"),
    ("Physics","bust"), ("Face","cheek, nose"), ("Eyes","eye, eyebrow"), ("Mouth","mouth"),
]

class UmaRigProps(PropertyGroup):
    # Objects
    armature_obj:  PointerProperty(name="Armature",  type=bpy.types.Object, poll=_poll_armature)
    face_mesh_obj: PointerProperty(name="Face Mesh", type=bpy.types.Object, poll=_poll_mesh)
    shape_key_mesh:PointerProperty(name="Mesh",      type=bpy.types.Object, poll=_poll_mesh)

    # Section toggles (all collapsed by default)
    show_skeleton_cleanup:  BoolProperty(default=False)
    show_finger:            BoolProperty(default=False)
    show_hand:              BoolProperty(default=False)
    show_ear:               BoolProperty(default=False)
    show_rig_cleanup:       BoolProperty(default=False)
    show_eye_rig:           BoolProperty(default=False)
    show_bone_coll:         BoolProperty(default=False)
    show_shape_keys:        BoolProperty(default=False)
    show_advanced:          BoolProperty(default=False)
    show_xrange_l:          BoolProperty(default=True)
    show_xrange_r:          BoolProperty(default=True)
    show_yrange_l:          BoolProperty(default=True)
    show_yrange_r:          BoolProperty(default=True)

    # Eye rig drivers
    xrange_l_min:  FloatProperty(name="Min",default=-1.0,soft_min=-5.0,soft_max=0.0,step=10,precision=3)
    xrange_l_max:  FloatProperty(name="Max",default=1.4, soft_min=0.0, soft_max=5.0,step=10,precision=3)
    xrange_l_expr: StringProperty(name="Expression",default="var * -1.5",maxlen=256)
    xrange_r_min:  FloatProperty(name="Min",default=-0.4)
    xrange_r_max:  FloatProperty(name="Max",default=1.4)
    xrange_r_expr: StringProperty(name="Expression",default="var * -1.5",maxlen=256)
    yrange_l_min:  FloatProperty(name="Min",default=-2.0)
    yrange_l_max:  FloatProperty(name="Max",default=2.0)
    yrange_l_expr: StringProperty(name="Expression",default="var * -1.5",maxlen=256)
    yrange_r_min:  FloatProperty(name="Min",default=-2.0)
    yrange_r_max:  FloatProperty(name="Max",default=2.0)
    yrange_r_expr: StringProperty(name="Expression",default="var * 1.5",maxlen=256)

    bone_collections: CollectionProperty(type=UmaBoneCollEntry)
    bone_coll_active: IntProperty(default=0)


# ─────────────────────────────────────────────────────────────────────────────
#  OPERATORS
# ─────────────────────────────────────────────────────────────────────────────

def _get_arm(context):
    props = context.scene.uma_rig
    return props.armature_obj

def _require_arm(self, context):
    obj = _get_arm(context)
    if obj is None:
        self.report({'ERROR'}, "Select an Armature first."); return None
    return obj


class UMARIG_OT_run_finger(Operator):
    bl_idname="uma_rig.run_finger"; bl_label="Build Finger Controller"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        obj = _require_arm(self, context)
        if obj is None: return {'CANCELLED'}
        try:
            bpy.context.view_layer.objects.active = obj
            run_finger_controller(obj)
            self.report({'INFO'}, "Finger Controller built ✓")
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_run_hand(Operator):
    bl_idname="uma_rig.run_hand"; bl_label="Build Hand Controller"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        obj = _require_arm(self, context)
        if obj is None: return {'CANCELLED'}
        try:
            bpy.context.view_layer.objects.active = obj
            run_hand_controller(obj)
            self.report({'INFO'}, "Hand Controller built ✓")
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_run_ear(Operator):
    bl_idname="uma_rig.run_ear"; bl_label="Build Ear Controller"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        obj = _require_arm(self, context)
        if obj is None: return {'CANCELLED'}
        try:
            bpy.context.view_layer.objects.active = obj
            run_ear_controller(obj)
            self.report({'INFO'}, "Ear Controller built ✓")
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_run_all(Operator):
    bl_idname="uma_rig.run_all"; bl_label="Build Fingers + Hands + Ears"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        obj = _require_arm(self, context)
        if obj is None: return {'CANCELLED'}
        try:
            bpy.context.view_layer.objects.active = obj
            run_finger_controller(obj)
            run_hand_controller(obj)
            run_ear_controller(obj)
            self.report({'INFO'}, "All controllers built ✓")
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_rig_cleanup(Operator):
    bl_idname="uma_rig.rig_cleanup"; bl_label="Cleanup Rig Controllers"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        obj = _require_arm(self, context)
        if obj is None: return {'CANCELLED'}
        try:
            bpy.context.view_layer.objects.active = obj
            run_cleanup(obj)
            self.report({'INFO'}, "Rig cleanup done ✓")
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_skeleton_cleanup(Operator):
    bl_idname="uma_rig.skeleton_cleanup"; bl_label="Clean Skeleton"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        obj = _require_arm(self, context)
        if obj is None: return {'CANCELLED'}
        try:
            bpy.context.view_layer.objects.active = obj
            n = run_skeleton_cleanup(obj)
            self.report({'INFO'}, f"Skeleton cleanup: {n} bones removed ✓")
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_shape_keys(Operator):
    bl_idname="uma_rig.shape_keys"; bl_label="Combine Shape Keys"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        props = context.scene.uma_rig
        obj = props.shape_key_mesh
        if obj is None:
            self.report({'ERROR'}, "Select a Mesh with shape keys first.")
            return {'CANCELLED'}
        try:
            n = run_shape_keys_combiner(obj)
            self.report({'INFO'}, f"{n} combined shape key(s) created ✓")
        except Exception as e:
            self.report({'ERROR'}, str(e)); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_eye_run(Operator):
    bl_idname="uma_rig.eye_run"; bl_label="Build Eye Rig"; bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        props=context.scene.uma_rig
        arm_obj=props.armature_obj; face_mesh=props.face_mesh_obj
        if arm_obj is None:
            self.report({'ERROR',"Select Armature first."}); return {'CANCELLED'}
        if face_mesh is None:
            self.report({'ERROR'},"Select Face Mesh first."); return {'CANCELLED'}
        try:
            bpy.context.view_layer.objects.active=arm_obj
            _create_eye_ctrl_bone(arm_obj)
            _reposition_eye_targets(arm_obj)
            _setup_eye_locator(arm_obj,EYE_LOCATOR_L,EYE_TARGET_LOC_L)
            _setup_eye_locator(arm_obj,EYE_LOCATOR_R,EYE_TARGET_LOC_R)
            p=props
            _setup_rotation_driver(face_mesh,arm_obj,SK_XRANGE_L,EYE_LOCATOR_L,1,p.xrange_l_expr,p.xrange_l_min,p.xrange_l_max)
            _setup_rotation_driver(face_mesh,arm_obj,SK_XRANGE_R,EYE_LOCATOR_R,1,p.xrange_r_expr,p.xrange_r_min,p.xrange_r_max)
            _setup_rotation_driver(face_mesh,arm_obj,SK_YRANGE_L,EYE_LOCATOR_L,0,p.yrange_l_expr,p.yrange_l_min,p.yrange_l_max)
            _setup_rotation_driver(face_mesh,arm_obj,SK_YRANGE_R,EYE_LOCATOR_R,0,p.yrange_r_expr,p.yrange_r_min,p.yrange_r_max)
            close_expr="min(max((1-var)/(1-0.8),0.0),1.0)"
            odoroki_expr="min(max((var-1)/(1.2-1),0.0),1.0)"
            for sk,bone in [(SK_CLOSE_L,EYE_LOCATOR_L),(SK_CLOSE_R,EYE_LOCATOR_R)]:
                _setup_scale_driver(face_mesh,arm_obj,sk,bone,close_expr)
            for sk,bone in [(SK_ODOROKI_L,EYE_LOCATOR_L),(SK_ODOROKI_R,EYE_LOCATOR_R)]:
                _setup_scale_driver(face_mesh,arm_obj,sk,bone,odoroki_expr)
            bpy.context.view_layer.update()
            self.report({'INFO'},"Eye Rig built ✓")
        except Exception as ex:
            try: bpy.ops.object.mode_set(mode='POSE')
            except Exception: pass
            self.report({'ERROR'},f"Setup failed: {ex}"); return {'CANCELLED'}
        return {'FINISHED'}


class UMARIG_OT_eye_reset(Operator):
    bl_idname="uma_rig.eye_reset"; bl_label="Reset Driver Defaults"; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.uma_rig
        p.xrange_l_min=-1.0; p.xrange_l_max=1.4; p.xrange_l_expr="var * -1.5"
        p.xrange_r_min=-0.4; p.xrange_r_max=1.4; p.xrange_r_expr="var * -1.5"
        p.yrange_l_min=-2.0; p.yrange_l_max=2.0; p.yrange_l_expr="var * -1.5"
        p.yrange_r_min=-2.0; p.yrange_r_max=2.0; p.yrange_r_expr="var * 1.5"
        self.report({'INFO'},"Defaults restored."); return {'FINISHED'}


class UMARIG_OT_coll_add(Operator):
    bl_idname="uma_rig.coll_add"; bl_label="Add Collection"; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        props=context.scene.uma_rig; e=props.bone_collections.add()
        e.coll_name="New Collection"; e.terms="keyword"
        props.bone_coll_active=len(props.bone_collections)-1; return {'FINISHED'}

class UMARIG_OT_coll_remove(Operator):
    bl_idname="uma_rig.coll_remove"; bl_label="Remove Collection"; bl_options={'REGISTER','UNDO'}
    index: IntProperty()
    def execute(self,context):
        props=context.scene.uma_rig
        if 0<=self.index<len(props.bone_collections):
            props.bone_collections.remove(self.index)
        return {'FINISHED'}

class UMARIG_OT_coll_reset(Operator):
    bl_idname="uma_rig.coll_reset"; bl_label="Reset Collections"; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        props=context.scene.uma_rig; props.bone_collections.clear()
        for name,terms in _DEFAULT_COLLECTIONS:
            e=props.bone_collections.add(); e.coll_name=name; e.terms=terms
        return {'FINISHED'}

class UMARIG_OT_build_collections(Operator):
    bl_idname="uma_rig.build_collections"; bl_label="Build Bone Collections"; bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        props=context.scene.uma_rig
        if props.armature_obj is None:
            self.report({'ERROR'},"No armature selected."); return {'CANCELLED'}
        try:
            counts=_setup_bone_collections(props.armature_obj,props.bone_collections,True)
            self.report({'INFO'},f"Collections built: {counts}")
        except Exception as e:
            self.report({'ERROR'},str(e)); return {'CANCELLED'}
        return {'FINISHED'}


# ─────────────────────────────────────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────────────────────────────────────

def _section_header(layout, props, show_attr, label, icon):
    box = layout.box()
    row = box.row(align=True)
    row.prop(props, show_attr,
             icon='TRIA_DOWN' if getattr(props, show_attr) else 'TRIA_RIGHT',
             icon_only=True, emboss=False)
    row.label(text=label, icon=icon)
    return box, getattr(props, show_attr)


class UMARIG_PT_main(Panel):
    bl_label       = "Uma Rig Tools"
    bl_idname      = "UMARIG_PT_main"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Uma Rig"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.uma_rig

        # ── Always visible: object pickers ───────────────────────────────────
        obj_box = layout.box()
        obj_box.label(text="Scene Objects", icon='SCENE_DATA')
        r=obj_box.row(align=True); r.alert=props.armature_obj is None
        r.prop(props,"armature_obj",text="Armature",icon='ARMATURE_DATA')

        layout.separator(factor=0.3)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 1. SKELETON CLEANUP
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_skeleton_cleanup",
                                      "Skeleton Cleanup", 'TRASH')
        if open_:
            box.separator(factor=0.2)
            info=box.column(); info.enabled=False
            info.label(text="Removes: *handle  |  Sp_He_Ear0_*", icon='INFO')
            box.separator(factor=0.3)
            r=box.row(); r.scale_y=1.4
            r.enabled=props.armature_obj is not None
            r.operator("uma_rig.skeleton_cleanup",icon='TRASH',text="Clean Skeleton")

        layout.separator(factor=0.2)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 2. FINGER CONTROLLER
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_finger",
                                      "Finger Controller", 'HAND')
        if open_:
            box.separator(factor=0.2)
            r=box.row(); r.scale_y=1.4
            r.enabled=props.armature_obj is not None
            r.operator("uma_rig.run_finger",icon='PLAY',text="Build Finger Controller")

        layout.separator(factor=0.2)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 3. HAND CONTROLLER
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_hand",
                                      "Hand Controller", 'VIEW_PAN')
        if open_:
            box.separator(factor=0.2)
            ap=_actions_path()
            info=box.column(); info.enabled=False
            info.label(text=f"actions.py: {'✓ found' if ap.exists() else '✗ NOT FOUND'}",
                       icon='CHECKMARK' if ap.exists() else 'ERROR')
            box.separator(factor=0.3)
            r=box.row(); r.scale_y=1.4
            r.enabled=props.armature_obj is not None
            r.operator("uma_rig.run_hand",icon='PLAY',text="Build Hand Controller")

        layout.separator(factor=0.2)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 4. EAR CONTROLLER
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_ear",
                                      "Ear Controller", 'OUTLINER_DATA_SPEAKER')
        if open_:
            box.separator(factor=0.2)
            r=box.row(); r.scale_y=1.4
            r.enabled=props.armature_obj is not None
            r.operator("uma_rig.run_ear",icon='PLAY',text="Build Ear Controller")

        layout.separator(factor=0.2)

        # ── Build All ─────────────────────────────────────────────────────────
        r=layout.row(); r.scale_y=1.6
        r.enabled=props.armature_obj is not None
        r.operator("uma_rig.run_all",icon='RENDER_ANIMATION',text="Build All Controllers")

        layout.separator(factor=0.4)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 5. RIG CLEANUP
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_rig_cleanup",
                                      "Rig Cleanup", 'LOOP_BACK')
        if open_:
            box.separator(factor=0.2)
            info=box.column(); info.enabled=False
            info.label(text="Removes _roll bones, hand_control, actions, constraints",icon='INFO')
            box.separator(factor=0.3)
            r=box.row(); r.scale_y=1.4; r.alert=True
            r.enabled=props.armature_obj is not None
            r.operator("uma_rig.rig_cleanup",icon='CANCEL',text="Cleanup Rig Controllers")

        layout.separator(factor=0.4)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 6. EYE RIG
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_eye_rig",
                                      "Eye Rig Setup", 'HIDE_OFF')
        if open_:
            box.separator(factor=0.2)
            r=box.row(align=True); r.alert=props.face_mesh_obj is None
            r.prop(props,"face_mesh_obj",text="Face Mesh",icon='MESH_DATA')

            def _draw_sk_block(parent, label, icon_name,
                                show_a, min_a, max_a, expr_a):
                sb=parent.box(); row=sb.row()
                row.prop(props,show_a,
                         icon='TRIA_DOWN' if getattr(props,show_a) else 'TRIA_RIGHT',
                         icon_only=True,emboss=False)
                row.label(text=label,icon=icon_name)
                if not getattr(props,show_a): return
                col=sb.column(align=True)
                r2=col.row(align=True)
                r2.prop(props,min_a,text="Min"); r2.prop(props,max_a,text="Max")
                sb.separator(factor=0.3)
                col2=sb.column(align=True)
                col2.label(text="Driver Expression (var):",icon='DRIVER')
                col2.prop(props,expr_a,text="")
                ok,msg=validate_expression(getattr(props,expr_a))
                if not ok:
                    r3=sb.row(); r3.alert=True; r3.label(text=f"⚠  {msg}",icon='ERROR')

            box.label(text="Shape Key Drivers", icon='SHAPEKEY_DATA')
            _draw_sk_block(box,"Eye_20_L  XRange",'EVENT_L','show_xrange_l','xrange_l_min','xrange_l_max','xrange_l_expr')
            _draw_sk_block(box,"Eye_20_R  XRange",'EVENT_R','show_xrange_r','xrange_r_min','xrange_r_max','xrange_r_expr')
            _draw_sk_block(box,"Eye_21_L  YRange",'EVENT_L','show_yrange_l','yrange_l_min','yrange_l_max','yrange_l_expr')
            _draw_sk_block(box,"Eye_21_R  YRange",'EVENT_R','show_yrange_r','yrange_r_min','yrange_r_max','yrange_r_expr')

            box.separator(factor=0.3)
            box.operator("uma_rig.eye_reset",text="Reset Defaults",icon='LOOP_BACK')
            box.separator(factor=0.4)
            r=box.row(); r.scale_y=1.6
            r.enabled = props.armature_obj is not None and props.face_mesh_obj is not None
            r.operator("uma_rig.eye_run",icon='PLAY',text="Build Eye Rig")

        layout.separator(factor=0.4)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 7. BONE COLLECTIONS
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_bone_coll",
                                      "Bone Collections", 'GROUP_BONE')
        if open_:
            box.separator(factor=0.2)
            rh=box.row(align=True)
            rh.operator("uma_rig.coll_add",text="",icon='ADD')
            rh.operator("uma_rig.coll_reset",text="",icon='LOOP_BACK')
            if not props.bone_collections:
                box.label(text="No collections. Click + to add.",icon='INFO')
            else:
                for i,entry in enumerate(props.bone_collections):
                    eb=box.box(); eh=eb.row(align=True)
                    eh.prop(entry,"coll_name",text="",icon='GROUP_BONE')
                    op=eh.operator("uma_rig.coll_remove",text="",icon='X'); op.index=i
                    eb.prop(entry,"terms",text="Prefixes")
            box.separator(factor=0.3)
            r=box.row(); r.scale_y=1.4
            r.enabled=props.armature_obj is not None
            r.operator("uma_rig.build_collections",icon='OUTLINER_OB_ARMATURE',text="Build Collections")

        layout.separator(factor=0.4)

        # ══════════════════════════════════════════════════════════════════════
        # ▶ 8. SHAPE KEYS COMBINER
        # ══════════════════════════════════════════════════════════════════════
        box, open_ = _section_header(layout, props, "show_shape_keys",
                                      "Shape Keys Combiner", 'SHAPEKEY_DATA')
        if open_:
            box.separator(factor=0.2)
            r=box.row(align=True); r.alert=props.shape_key_mesh is None
            r.prop(props,"shape_key_mesh",text="Mesh",icon='MESH_DATA')
            box.separator(factor=0.3)
            info=box.column(); info.enabled=False
            info.label(text="Combines _L + _R pairs into a single shape key",icon='INFO')
            box.separator(factor=0.3)
            r=box.row(); r.scale_y=1.4
            r.enabled=props.shape_key_mesh is not None
            r.operator("uma_rig.shape_keys",icon='PLAY',text="Combine Shape Keys")


# ─────────────────────────────────────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────────────────────────────────────

_classes = (
    UmaBoneCollEntry, UmaRigProps,
    UMARIG_OT_run_finger, UMARIG_OT_run_hand, UMARIG_OT_run_ear,
    UMARIG_OT_run_all, UMARIG_OT_rig_cleanup, UMARIG_OT_skeleton_cleanup,
    UMARIG_OT_shape_keys,
    UMARIG_OT_eye_run, UMARIG_OT_eye_reset,
    UMARIG_OT_coll_add, UMARIG_OT_coll_remove, UMARIG_OT_coll_reset,
    UMARIG_OT_build_collections,
    UMARIG_PT_main,
)

def _seed_bone_collections(dummy=None):
    for scene in bpy.data.scenes:
        props=scene.uma_rig
        if len(props.bone_collections)==0:
            for name,terms in _DEFAULT_COLLECTIONS:
                e=props.bone_collections.add(); e.coll_name=name; e.terms=terms
    if _seed_bone_collections in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_seed_bone_collections)

def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.uma_rig=PointerProperty(type=UmaRigProps)
    bpy.app.handlers.depsgraph_update_post.append(_seed_bone_collections)

def unregister():
    if _seed_bone_collections in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_seed_bone_collections)
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.uma_rig

if __name__=="__main__":
    register()
